/*
 * setup.h
 *
 *  Created on: 12.02.2025
 *      Author: marvi
 */

#ifndef SETUP_SETUP_H_
#define SETUP_SETUP_H_

void Help(const char *pProgName);
int Main(int argc, const char* argv[]);
int MainA(const char *pProgName, const char *pCmdLine);

#endif /* SETUP_SETUP_H_ */
